from distutils.core import setup

setup(name="liuhao", version="1.0", 
    description="liuhao's module", author="liuhao", 
    py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
